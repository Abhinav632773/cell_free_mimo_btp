%% =========================================================================
% plot_isac_pareto.m
% 
% Fetches data from: results/isac_pareto.csv
% Generates: ISAC Pareto Trade-off Front (Comm Min Rate vs. Radar Sensing SNR)
% Exactly matches the visual comparison in "cell_free_mimo2-mainimagr.jpeg"
%
% All styling parameters (axes limits, labels, colors, font sizes, markers,
% line widths, annotations) are placed in the EDITABLE PARAMETERS section below.
% =========================================================================

clear; clc; close all;

%% =========================================================================
%% 1. EDITABLE PARAMETERS (CUSTOMIZE AXES, LABELS, COLORS, ANNOTATIONS HERE)
%% =========================================================================

% --- File Paths ---
csvFilePath   = fullfile('results', 'isac_pareto.csv');
outputFigPath = fullfile('results', 'matlab_isac_pareto.png');

% --- Figure Window Properties ---
figWidth  = 950;     % Width in pixels
figHeight = 620;     % Height in pixels
fontName  = 'Helvetica';
titleFontSize  = 13;
labelFontSize  = 11.5;
axisFontSize   = 10.5;
legendFontSize = 11;
annotFontSize  = 9.5;

% --- Main Titles & Axis Labels ---
plotTitle = 'ISAC Pareto Trade-off Front: Comm Min Rate vs. Radar Sensing SNR';
xLabelStr = 'Target Radar Echo SNR [dB]';
yLabelStr = 'Min User Communication Rate [bits/s/Hz]';

% --- Axis Limits & Ticks (Set to [] for auto-scaling) ---
xLimits = [40.5, 44.6];               % X-axis range: [min, max]
yLimits = [0.4, 3.7];                 % Y-axis range: [min, max]
xTicks  = 40.5:0.5:44.5;              % Explicit X tick marks
yTicks  = 0.5:0.5:3.5;                % Explicit Y tick marks

% --- Curve 1: Search-based + DFRC ---
c1_Name       = 'Search-based + DFRC';
c1_Color      = [1.00, 0.50, 0.00];   % Vivid Orange
c1_Marker     = 's';                  % Square
c1_MarkerSize = 7;
c1_LineWidth  = 2.2;

% --- Curve 2: QNN + DFRC (Proposed) ---
c2_Name       = 'QNN + DFRC';
c2_Color      = [0.00, 0.10, 0.90];   % Vivid Blue
c2_Marker     = 'o';                  % Circle
c2_MarkerSize = 7;
c2_LineWidth  = 2.2;

% --- Curve 3: Random + DFRC ---
c3_Name       = 'Random + DFRC';
c3_Color      = [0.50, 0.50, 0.50];   % Grey
c3_Marker     = '^';                  % Triangle
c3_MarkerSize = 7;
c3_LineWidth  = 2.2;

% --- Annotations (eta = 0.0, 0.2, 0.5, 0.85) ---
showAnnotations = true;
annotEtas = [0.0, 0.2, 0.5, 0.85];   % Power ratios to annotate

% Offset (dx, dy) for annotation text placement to prevent overlapping
annotOffsets = containers.Map();
% Key format: 'Method_eta'
annotOffsets('Search_0.0')  = [-0.08,  0.08];
annotOffsets('Search_0.2')  = [ 0.01,  0.08];
annotOffsets('Search_0.5')  = [ 0.01,  0.08];
annotOffsets('Search_0.85') = [ 0.01,  0.08];

annotOffsets('QNN_0.0')     = [-0.06,  0.08];
annotOffsets('QNN_0.2')     = [ 0.01,  0.08];
annotOffsets('QNN_0.5')     = [ 0.02,  0.08];
annotOffsets('QNN_0.85')    = [ 0.01,  0.08];

annotOffsets('Random_0.0')  = [-0.10,  0.08];
annotOffsets('Random_0.2')  = [-0.10,  0.08];
annotOffsets('Random_0.5')  = [ 0.01,  0.08];
annotOffsets('Random_0.85') = [ 0.01,  0.08];

% --- Grid & Legend ---
enableGrid    = true;
gridLineStyle = '--';
gridAlpha     = 0.5;
legendLocation = 'northeast';

%% =========================================================================
%% 2. DATA IMPORT & EXTRACTION
%% =========================================================================

if ~exist(csvFilePath, 'file')
    error('File not found: %s\nRun "python main.py" or check results folder.', csvFilePath);
end

try
    T = readtable(csvFilePath, 'VariableNamingRule', 'preserve');
catch
    T = readtable(csvFilePath);
end

% Columns:
% 1: Radar Power Ratio (eta)
% 2: Method
% 3: Min Comm Rate [bits/s/Hz]
% 4: Radar Echo SNR [dB]
% 5: Sensing Rate [bits/s/Hz]

etaCol     = T{:, 1};
methodCol  = string(T{:, 2});
commRate   = T{:, 3};
radarSNR   = T{:, 4};

% Filter points per method
idxSearch = contains(methodCol, 'Search', 'IgnoreCase', true);
idxQNN    = contains(methodCol, 'QNN', 'IgnoreCase', true);
idxRandom = contains(methodCol, 'Random', 'IgnoreCase', true);

search_SNR  = radarSNR(idxSearch);
search_Rate = commRate(idxSearch);
search_eta  = etaCol(idxSearch);

qnn_SNR     = radarSNR(idxQNN);
qnn_Rate    = commRate(idxQNN);
qnn_eta     = etaCol(idxQNN);

rand_SNR    = radarSNR(idxRandom);
rand_Rate   = commRate(idxRandom);
rand_eta    = etaCol(idxRandom);

%% =========================================================================
%% 3. PLOTTING
%% =========================================================================

fig = figure('Color', 'w', 'Position', [150, 150, figWidth, figHeight]);
hold on; box on;

% Plot Curves
h1 = plot(search_SNR, search_Rate, '-', 'Color', c1_Color, ...
    'LineWidth', c1_LineWidth, 'Marker', c1_Marker, 'MarkerSize', c1_MarkerSize, ...
    'MarkerFaceColor', c1_Color, 'DisplayName', c1_Name);

h2 = plot(qnn_SNR, qnn_Rate, '-', 'Color', c2_Color, ...
    'LineWidth', c2_LineWidth, 'Marker', c2_Marker, 'MarkerSize', c2_MarkerSize, ...
    'MarkerFaceColor', c2_Color, 'DisplayName', c2_Name);

h3 = plot(rand_SNR, rand_Rate, '-', 'Color', c3_Color, ...
    'LineWidth', c3_LineWidth, 'Marker', c3_Marker, 'MarkerSize', c3_MarkerSize, ...
    'MarkerFaceColor', c3_Color, 'DisplayName', c3_Name);

% Add Annotations (\eta = ...)
if showAnnotations
    % Helper function for placing annotations
    add_annot = @(x, y, etaVal, labelPrefix, textColor) ...
        text(x + annotOffsets([labelPrefix '_' num2str(etaVal)])(1), ...
             y + annotOffsets([labelPrefix '_' num2str(etaVal)])(2), ...
             sprintf('\\eta=%.1f', etaVal), ...
             'Color', textColor, 'FontSize', annotFontSize, ...
             'FontName', fontName, 'FontWeight', 'bold');
         
    for i = 1:length(annotEtas)
        targetEta = annotEtas(i);
        
        % Search
        k = find(abs(search_eta - targetEta) < 1e-4, 1);
        if ~isempty(k)
            add_annot(search_SNR(k), search_Rate(k), targetEta, 'Search', c1_Color);
        end
        
        % QNN
        k = find(abs(qnn_eta - targetEta) < 1e-4, 1);
        if ~isempty(k)
            add_annot(qnn_SNR(k), qnn_Rate(k), targetEta, 'QNN', c2_Color);
        end
        
        % Random
        k = find(abs(rand_eta - targetEta) < 1e-4, 1);
        if ~isempty(k)
            add_annot(rand_SNR(k), rand_Rate(k), targetEta, 'Random', c3_Color);
        end
    end
end

% Axes Styling
title(plotTitle, 'FontSize', titleFontSize, 'FontName', fontName, 'FontWeight', 'bold');
xlabel(xLabelStr, 'FontSize', labelFontSize, 'FontName', fontName, 'FontWeight', 'normal');
ylabel(yLabelStr, 'FontSize', labelFontSize, 'FontName', fontName, 'FontWeight', 'normal');
set(gca, 'FontName', fontName, 'FontSize', axisFontSize, 'LineWidth', 1.0);

if ~isempty(xLimits), xlim(xLimits); end
if ~isempty(yLimits), ylim(yLimits); end
if ~isempty(xTicks),  xticks(xTicks); end
if ~isempty(yTicks),  yticks(yTicks); end

if enableGrid
    grid on;
    ax = gca;
    ax.GridLineStyle = gridLineStyle;
    ax.GridAlpha = gridAlpha;
end

% Legend
lgd = legend([h1, h2, h3], 'Location', legendLocation, 'FontSize', legendFontSize, 'FontName', fontName);
set(lgd, 'EdgeColor', [0.8, 0.8, 0.8]);

hold off;

%% =========================================================================
%% 4. EXPORT HIGH-RESOLUTION FIGURE
%% =========================================================================

if exist('exportgraphics', 'file') || exist('exportgraphics', 'builtin')
    exportgraphics(fig, outputFigPath, 'Resolution', 300);
else
    print(fig, outputFigPath, '-dpng', '-r300');
end
fprintf('[OK] ISAC Pareto plot saved to: %s\n', outputFigPath);
