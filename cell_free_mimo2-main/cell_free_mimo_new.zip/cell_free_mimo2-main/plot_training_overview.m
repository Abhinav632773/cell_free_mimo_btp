%% =========================================================================
% plot_training_overview.m
% 
% Fetches data from: results/training_history.csv
% Generates: 2x2 Training Overview (Cloud Loss, Edge Loss, Min Rate, Sum Rate)
%
% All styling parameters (axes limits, labels, colors, font sizes, line widths)
% are organized in the EDITABLE PARAMETERS section below for easy modification.
% =========================================================================

clear; clc; close all;

%% =========================================================================
%% 1. EDITABLE PARAMETERS (CUSTOMIZE AXES, LABELS, COLORS, FONTS HERE)
%% =========================================================================

% --- File Paths ---
csvFilePath = fullfile('results', 'training_history.csv');
outputFigPath = fullfile('results', 'matlab_training_overview.png');

% --- Figure Window Properties ---
figWidth  = 1100;    % Width in pixels
figHeight = 750;     % Height in pixels
fontName  = 'Helvetica';
titleFontSize = 12;
labelFontSize = 11;
axisFontSize  = 10;
superTitleFontSize = 15;

% --- Subplot 1: Cloud QNN Loss (Top-Left) ---
sub1_Color     = [0.90, 0.20, 0.20];  % Red (RGB: 0 to 1)
sub1_LineWidth = 2.0;
sub1_Title     = 'Cloud QNN Loss (\downarrow better)';
sub1_XLabel    = 'Epoch';
sub1_YLabel    = 'Cloud Loss (L_{assign})';
sub1_XLim      = [0, 100];            % Set [] for auto-scale, or e.g. [0, 100]
sub1_YLim      = [0.18, 0.30];        % Set [] for auto-scale, or e.g. [0.15, 0.32]

% --- Subplot 2: Edge QNN Loss (Top-Right) ---
sub2_Color     = [0.15, 0.70, 0.25];  % Green
sub2_LineWidth = 2.0;
sub2_Title     = 'Edge QNN Loss (\downarrow better)';
sub2_XLabel    = 'Epoch';
sub2_YLabel    = 'Edge Loss (L_{precode})';
sub2_XLim      = [0, 100];            % Set [] for auto-scale
sub2_YLim      = [0.65, 1.25];        % Set [] for auto-scale

% --- Subplot 3: Minimum User Rate (Bottom-Left) ---
sub3_Color     = [0.15, 0.40, 0.90];  % Blue
sub3_LineWidth = 2.0;
sub3_Title     = 'Minimum User Rate (\uparrow better)';
sub3_XLabel    = 'Epoch';
sub3_YLabel    = 'Min Rate [bits/s/Hz]';
sub3_XLim      = [0, 100];            % Set [] for auto-scale
sub3_YLim      = [0.90, 1.35];        % Set [] for auto-scale

% --- Subplot 4: Sum Rate (Bottom-Right) ---
sub4_Color     = [0.75, 0.15, 0.85];  % Magenta / Purple
sub4_LineWidth = 2.0;
sub4_Title     = 'Sum Rate (\uparrow better)';
sub4_XLabel    = 'Epoch';
sub4_YLabel    = 'Sum Rate [bits/s/Hz]';
sub4_XLim      = [0, 100];            % Set [] for auto-scale
sub4_YLim      = [8.50, 10.20];       % Set [] for auto-scale

% --- Grid Properties ---
enableGrid     = true;
gridLineStyle  = ':';                 % ':', '--', '-'
gridAlpha      = 0.6;                 % Transparency: 0 (invisible) to 1 (solid)

%% =========================================================================
%% 2. DATA IMPORT (ROBUST ACROSS ALL MATLAB VERSIONS)
%% =========================================================================

if ~exist(csvFilePath, 'file')
    error('File not found: %s\nMake sure you are in the cell_free_mimo2-main directory.', csvFilePath);
end

% Read CSV into table
try
    dataTbl = readtable(csvFilePath, 'VariableNamingRule', 'preserve');
catch
    dataTbl = readtable(csvFilePath);
end

% Extract columns using numeric indices (guarantees compatibility regardless of headers)
epochs    = dataTbl{:, 1};
cloudLoss = dataTbl{:, 2};
edgeLoss  = dataTbl{:, 3};
minRate   = dataTbl{:, 4};
sumRate   = dataTbl{:, 5};

%% =========================================================================
%% 3. PLOTTING (2x2 GRID)
%% =========================================================================

fig = figure('Color', 'w', 'Position', [100, 100, figWidth, figHeight]);

% --- (1) Cloud Loss ---
subplot(2, 2, 1);
plot(epochs, cloudLoss, 'Color', sub1_Color, 'LineWidth', sub1_LineWidth);
title(sub1_Title, 'FontSize', titleFontSize, 'FontName', fontName, 'FontWeight', 'bold');
xlabel(sub1_XLabel, 'FontSize', labelFontSize, 'FontName', fontName);
ylabel(sub1_YLabel, 'FontSize', labelFontSize, 'FontName', fontName);
set(gca, 'FontName', fontName, 'FontSize', axisFontSize);
if ~isempty(sub1_XLim), xlim(sub1_XLim); end
if ~isempty(sub1_YLim), ylim(sub1_YLim); end
if enableGrid
    grid on; ax = gca; ax.GridLineStyle = gridLineStyle; ax.GridAlpha = gridAlpha;
end

% --- (2) Edge Loss ---
subplot(2, 2, 2);
plot(epochs, edgeLoss, 'Color', sub2_Color, 'LineWidth', sub2_LineWidth);
title(sub2_Title, 'FontSize', titleFontSize, 'FontName', fontName, 'FontWeight', 'bold');
xlabel(sub2_XLabel, 'FontSize', labelFontSize, 'FontName', fontName);
ylabel(sub2_YLabel, 'FontSize', labelFontSize, 'FontName', fontName);
set(gca, 'FontName', fontName, 'FontSize', axisFontSize);
if ~isempty(sub2_XLim), xlim(sub2_XLim); end
if ~isempty(sub2_YLim), ylim(sub2_YLim); end
if enableGrid
    grid on; ax = gca; ax.GridLineStyle = gridLineStyle; ax.GridAlpha = gridAlpha;
end

% --- (3) Minimum User Rate ---
subplot(2, 2, 3);
plot(epochs, minRate, 'Color', sub3_Color, 'LineWidth', sub3_LineWidth);
title(sub3_Title, 'FontSize', titleFontSize, 'FontName', fontName, 'FontWeight', 'bold');
xlabel(sub3_XLabel, 'FontSize', labelFontSize, 'FontName', fontName);
ylabel(sub3_YLabel, 'FontSize', labelFontSize, 'FontName', fontName);
set(gca, 'FontName', fontName, 'FontSize', axisFontSize);
if ~isempty(sub3_XLim), xlim(sub3_XLim); end
if ~isempty(sub3_YLim), ylim(sub3_YLim); end
if enableGrid
    grid on; ax = gca; ax.GridLineStyle = gridLineStyle; ax.GridAlpha = gridAlpha;
end

% --- (4) Sum Rate ---
subplot(2, 2, 4);
plot(epochs, sumRate, 'Color', sub4_Color, 'LineWidth', sub4_LineWidth);
title(sub4_Title, 'FontSize', titleFontSize, 'FontName', fontName, 'FontWeight', 'bold');
xlabel(sub4_XLabel, 'FontSize', labelFontSize, 'FontName', fontName);
ylabel(sub4_YLabel, 'FontSize', labelFontSize, 'FontName', fontName);
set(gca, 'FontName', fontName, 'FontSize', axisFontSize);
if ~isempty(sub4_XLim), xlim(sub4_XLim); end
if ~isempty(sub4_YLim), ylim(sub4_YLim); end
if enableGrid
    grid on; ax = gca; ax.GridLineStyle = gridLineStyle; ax.GridAlpha = gridAlpha;
end

% Global Super-Title
sgtitle('Training Overview', 'FontSize', superTitleFontSize, 'FontName', fontName, 'FontWeight', 'bold');

%% =========================================================================
%% 4. EXPORT HIGH-RESOLUTION FIGURE
%% =========================================================================

if exist('exportgraphics', 'file') || exist('exportgraphics', 'builtin')
    exportgraphics(fig, outputFigPath, 'Resolution', 300);
else
    print(fig, outputFigPath, '-dpng', '-r300');
end
fprintf('[OK] Training overview plot saved to: %s\n', outputFigPath);
