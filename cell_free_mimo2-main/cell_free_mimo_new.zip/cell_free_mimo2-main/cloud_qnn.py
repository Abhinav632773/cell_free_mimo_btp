# cloud_qnn.py
"""
Cloud QNN for Transmitter-User Assignment (Section IV-A).

Takes complete channel information from all APs.
Outputs which AP should serve which user.

Architecture (Eq. 10):
    U_cloud = U_connect(theta) · U_encode(H)

    Encoding:   H then RZ(h_mk) per user, on the first-layer qubit of AP m
    Connection: CZ + RY(theta) per layer, CX neuron n → neuron n of next layer
    Output:     Measure last layer → decode into assignment
"""

import pennylane as qml
from pennylane import numpy as np
import config


class CloudQNN:
    def __init__(self):
        # Circuit dimensions
        self.n_layers = config.N_LAYER_CLOUD     # 3
        self.n_neurons = config.N_AP             # 4 (one output per AP)
        self.n_qubits = self.n_layers * self.n_neurons  # 3 × 4 = 12
        
        # Quantum device (simulator)
        self.dev = qml.device("default.qubit", wires=self.n_qubits)
        
        # Trainable parameters: one angle per qubit
        # Shape: (n_layers, n_neurons)
        self.params = np.random.uniform(
            0, 2 * np.pi,
            size=(self.n_layers, self.n_neurons),
            requires_grad=True
        )
        
        # Build the quantum circuit as a QNode
        self.circuit = qml.QNode(self._circuit, self.dev, interface="autograd")
    
    def _encode(self, features):
        """
        Encoding operation (Eq. 11).
        
        U_encode = ⊗_m  Π_k  RZ(h_mk) H   on the first-layer qubit of AP m
        
        H comes first: it puts the qubit in superposition so that the
        RZ phase rotation is not lost (RZ on |0⟩ is only a global phase).
        All other qubits stay in |0⟩ (the paper's initial state).
        
        In LEGACY_MODE the old order (RZ then H, one value per qubit)
        is kept; it ignores the input entirely.
        """
        if config.LEGACY_MODE:
            for i in range(self.n_qubits):
                if i < len(features):
                    qml.RZ(features[i], wires=i)
                qml.Hadamard(wires=i)
            return
        
        for m in range(config.N_AP):
            # features is ordered AP-major: features[m * N_USER + k]
            for k in range(config.N_USER):
                qml.Hadamard(wires=m)
                qml.RZ(features[m * config.N_USER + k], wires=m)
    
    def _connect(self, params):
        """
        Connection operation (based on Eq. 12).
        
        For each layer:
          1. CZ between adjacent qubits in same layer — entanglement
          2. RY(θ) on each qubit — TRAINABLE weights
          3. CX from neuron n of this layer to neuron n of the next layer
        
        This is like a neural network:
          RY = weights
          CZ = connections within a layer  
          CX = connections between layers
        
        Why not Eq. 12 literally (RY, then one CX last → first neuron,
        then CZ)? CZ only changes phases and nothing rotates them back
        afterwards, so the measured last layer never depends on the
        input. Putting CZ before RY turns the phases into probabilities,
        and one CX per neuron carries every neuron to the next layer.
        LEGACY_MODE keeps the old circuit.
        """
        if config.LEGACY_MODE:
            for l in range(self.n_layers):
                for n in range(self.n_neurons):
                    qml.RY(params[l, n], wires=l * self.n_neurons + n)
                for n in range(self.n_neurons - 1):
                    qml.CZ(wires=[l * self.n_neurons + n, l * self.n_neurons + n + 1])
                if l < self.n_layers - 1:
                    qml.CNOT(wires=[l * self.n_neurons + self.n_neurons - 1,
                                    (l + 1) * self.n_neurons])
            return
        
        for l in range(self.n_layers):
            # Step 1: CZ entanglement within the layer
            # Connect adjacent neurons: q0-q1, q1-q2, q2-q3
            for n in range(self.n_neurons - 1):
                q1 = l * self.n_neurons + n
                q2 = l * self.n_neurons + n + 1
                qml.CZ(wires=[q1, q2])
            
            # Step 2: Trainable RY rotations (the "weights")
            for n in range(self.n_neurons):
                qubit = l * self.n_neurons + n
                qml.RY(params[l, n], wires=qubit)
            
            # Step 3: CX connection to next layer, neuron by neuron
            if l < self.n_layers - 1:
                for n in range(self.n_neurons):
                    qml.CNOT(wires=[l * self.n_neurons + n,
                                    (l + 1) * self.n_neurons + n])
    
    def _circuit(self, params, features):
        """
        The complete cloud QNN circuit.
        
        All qubits start as |0⟩
        → Encode channel data (RZ + H)
        → Process through trainable gates (RY + CZ + CX)
        → Measure the output layer
        """
        # Encode channel information into qubits
        self._encode(features)
        
        # Apply trainable connection circuit
        self._connect(params)
        
        # Measure the LAST LAYER only (these are our outputs)
        # Last layer qubits: indices [8, 9, 10, 11] for 3 layers × 4 neurons
        last_layer_start = (self.n_layers - 1) * self.n_neurons
        output_wires = list(range(last_layer_start,
                                   last_layer_start + self.n_neurons))
        
        return qml.probs(wires=output_wires)
    
    def forward(self, features):
        """Run the circuit with current parameters."""
        return self.circuit(self.params, features)
    
    def prepare_features(self, H_matrix):
        """
        Convert channel feature matrix into QNN input.
        
        One value per AP-user pair: ||h_mk|| in dB, scaled to [0, π]
        (not 2π, because RZ(0) and RZ(2π) give the same state).
        Output is ordered AP-major: N_AP × N_USER values.
        
        In LEGACY_MODE the old version is kept: |Re|, |Im| of every entry
        scaled to [0, 2π] (only the first 12 values, AP 0, were ever used).
        """
        if config.LEGACY_MODE:
            flat = np.abs(H_matrix).flatten()
            max_val = np.max(flat) + 1e-10
            return 2 * np.pi * flat / max_val
        
        # H_matrix row m = [Re h_m0, Im h_m0, Re h_m1, Im h_m1, ...]
        blocks = np.asarray(H_matrix).reshape(config.N_AP, config.N_USER, 2 * config.N_TX)
        norms = np.sqrt(np.sum(blocks ** 2, axis=2))
        db = 10 * np.log10(norms ** 2 + 1e-30)
        span = np.max(db) - np.min(db)
        scaled = (db - np.min(db)) / span if span > 0 else np.zeros_like(db)
        return np.pi * scaled.flatten()
    
    def decode_assignment(self, probs):
        """
        Convert QNN output probabilities into assignment matrix γ.
        
        For each AP m:
            1. Compute marginal probability of qubit m being |1⟩
            2. Map to user index: user = floor(prob × N_USER)
            3. Set γ[m, user] = 1
        
        Also ensures every user gets at least one AP.
        """
        gamma = np.zeros((config.N_AP, config.N_USER))
        n_output = min(self.n_neurons, config.N_AP)
        
        for m in range(config.N_AP):
            if m < n_output:
                # Marginal probability of qubit m being |1⟩
                # Sum over all states where bit m is 1
                prob_one = 0.0
                n_states = len(probs)
                for state_idx in range(n_states):
                    # Check if bit m is 1 in this state
                    if (state_idx >> (n_output - 1 - m)) & 1:
                        prob_one += float(probs[state_idx])
                
                # Map probability [0,1] to user index [0, N_USER-1]
                user = int(np.floor(prob_one * config.N_USER))
                user = min(user, config.N_USER - 1)
                user = max(user, 0)
            else:
                user = m % config.N_USER
            
            gamma[m, user] = 1
        
        # Ensure every user has at least one AP (Eq. 6c)
        gamma = self._enforce_coverage(gamma)
        
        return gamma
    
    def _enforce_coverage(self, gamma):
        """Make sure no user is left without an AP."""
        for k in range(config.N_USER):
            if np.sum(gamma[:, k]) == 0:
                # Find an AP serving a user that has multiple APs
                ap_counts = np.sum(gamma, axis=1)
                user_ap_counts = np.sum(gamma, axis=0)
                
                # Find user with most APs
                rich_user = np.argmax(user_ap_counts)
                
                # Take one AP from that user
                aps_of_rich = np.where(gamma[:, rich_user] == 1)[0]
                if len(aps_of_rich) > 1:
                    m_reassign = aps_of_rich[0]
                    gamma[m_reassign, rich_user] = 0
                    gamma[m_reassign, k] = 1
                else:
                    # Last resort: just reassign any AP
                    m_reassign = np.random.randint(0, config.N_AP)
                    gamma[m_reassign, :] = 0
                    gamma[m_reassign, k] = 1
        
        return gamma
    
    def compute_target(self, H, rho):
        """
        Compute ideal target performance Φ_assign (reference point).
        
        Based on eigenvalue decomposition of channel matrix.
        This is the "best possible" performance we aim toward.
        """
        total = 0.0
        for m in range(config.N_AP):
            # Build channel matrix for AP m: (N_TX × N_USER)
            H_m = np.zeros((config.N_TX, config.N_USER), dtype=complex)
            for k in range(config.N_USER):
                H_m[:, k] = H[(m, k)]
            
            # Eigenvalues represent the "capacity" of each channel mode
            eigenvalues = np.linalg.eigvalsh(H_m @ H_m.conj().T)
            eigenvalues = np.maximum(eigenvalues, 0)
            N_lam = max(len(eigenvalues), 1)
            
            for lam in eigenvalues:
                total -= np.log2(1 + lam / N_lam * rho)
        
        return float(total)


# ---- Quick test ----
if __name__ == "__main__":
    from channel import generate_positions, compute_distances, generate_sample
    from rates import compute_mr_precoding, compute_user_rates, build_precoding_from_assignment
    
    # Generate channel data
    ap_pos, user_pos = generate_positions(seed=42)
    dist = compute_distances(ap_pos, user_pos)
    H, H_matrix = generate_sample(dist)
    
    # Create cloud QNN
    cloud = CloudQNN()
    
    print("=" * 50)
    print("Cloud QNN Test")
    print("=" * 50)
    print(f"  Qubits: {cloud.n_qubits}")
    print(f"  Trainable parameters: {cloud.params.size}")
    print(f"  Parameter shape: {cloud.params.shape}")
    
    # Prepare features
    features = cloud.prepare_features(H_matrix)
    print(f"\n  Input features: {len(features)} values")
    
    # Run forward pass
    output = cloud.forward(features)
    print(f"  Output shape: {output.shape}")
    print(f"  Output (first 8 probs): {np.round(output[:8], 4)}")
    
    # Decode assignment
    gamma = cloud.decode_assignment(output)
    print(f"\n  Decoded assignment γ:")
    print(f"  {gamma.astype(int)}")
    
    # Check: which user does each AP serve?
    for m in range(config.N_AP):
        user = np.argmax(gamma[m])
        print(f"    AP{m} → User{user}")
    
    # Compute rates with this assignment
    V = build_precoding_from_assignment(H, gamma)
    rates = compute_user_rates(H, gamma, V)
    print(f"\n  User rates: {np.round(rates, 4)}")
    print(f"  Min rate: {np.min(rates):.4f}")
    
    # Show the circuit
    print(f"\n--- Circuit Diagram ---")
    try:
        print(qml.draw(cloud.circuit)(cloud.params, features))
    except:
        print("  (Circuit too large to display in text)")
    
    print("\n  The QNN works! But with random weights,")
    print("  the assignment is random too. Training will fix this.")